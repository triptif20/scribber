# Scribbler_Project_Upgrad
Frontend Upgrad Scribbler Project assigned by upgrad Learn In FullStack Development 

   ## Home Page
   - Home Page
   
        <img src="https://user-images.githubusercontent.com/68987615/186209276-01ca7aad-692d-475f-aaaf-3560c0916b9d.jpg" height="500px" width="auto" alt="img1"/>
        <br/>
   - SignUp
   
        <img src="https://user-images.githubusercontent.com/68987615/186209462-bfa1de59-ed2b-48dd-9178-ce621872036f.jpg" alt="img2" height="500px" width="auto"/>
        <br/>
   - SignIn
   
        <img src="https://user-images.githubusercontent.com/68987615/186209428-875c7109-6971-4c8e-86ad-8b14e2579cbb.jpg" alt="img3" height="500px" width="auto"/>
        <br/>
   - Create Post
   
        <img src="https://user-images.githubusercontent.com/68987615/186209624-09684b94-2e69-4c9e-8e2f-9bc488c96f49.jpg" alt="img4" height="500px" width="auto"/>
        <br/>
        <hr/>
   ## Post Part
   - View Post
   
        
        <img src="https://user-images.githubusercontent.com/68987615/186209497-92ee341b-37de-4c82-9316-44202bdaa23a.jpg" alt="img5" height="500px" width="auto"/>
        <br/>
   - Delete Post
       
        <img src="https://user-images.githubusercontent.com/68987615/186209564-9dc3b0be-6b5d-4a63-8cf8-fdf0774cd2d9.jpg" alt="img6" height="500px" width="auto"/>
        <br/>
        <hr/>
   ## Post Detail Part 
   - Like 
   - Comment
   - Edit/Save Post
   
        <img src="https://user-images.githubusercontent.com/68987615/186209333-d3fb2b4b-da96-4c21-bc6c-40781d5492f3.jpg" alt="img7" height="500px" width="auto"/>

   
