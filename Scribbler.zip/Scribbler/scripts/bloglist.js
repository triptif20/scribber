//  Use to navigate to next page

function PostDetailPage() {
  window.location.href = "../html/post.html";
}
